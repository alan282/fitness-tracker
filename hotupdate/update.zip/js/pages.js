/* ── 页面渲染：今日 / 方案 / 动作库 / 数据 / 设置 / 训练执行 / 弹窗 ── */

const Pages = {
  current: null,

  render(page) {
    this.current = page;
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    document.querySelectorAll('.tabbar button').forEach(b => b.classList.toggle('active', b.dataset.page === page));
    const el = document.getElementById('page-' + page);
    if (el) {
      const map = {
        today: () => this.today(el),
        plan: () => this.plan(el),
        library: () => this.library(el),
        stats: () => this.stats(el),
        settings: () => App.settings(el),
        workout: () => { if (Workout.session) Workout.render(el); else return this.today(el); },
      };
      (map[page] || (() => {}))();
      el.classList.add('active');
      window.scrollTo(0, 0);
    }
  },

  /* ── 今日页 ── */
  today(el) {
    const plan = DB.getPlan();
    if (!plan) { el.innerHTML = '<div class="empty"><div class="big">无方案</div><p>还没有训练方案</p><button class="btn primary" onclick="App.go(\'settings\')">去创建方案</button></div>'; return; }
    const st = DB.getPlanState();
    const dayIdx = st.dayCursor % plan.days.length;
    const day = plan.days[dayIdx];
    const workouts = DB.getWorkouts();

    // 数据易失环境提示（微信内浏览器的本地存储不持久，杀掉微信数据即丢失；原生 APP 无此问题）
    let storageHint = '';
    if (!window.Capacitor && !localStorage.getItem('gym_storage_hint_ok')) {
      const ua = navigator.userAgent;
      const inWeChat = /MicroMessenger/i.test(ua);
      const isIOS = /iPad|iPhone|iPod/.test(ua) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
      if (inWeChat || isIOS) {
        storageHint = `<div class="card" style="display:flex;gap:10px;align-items:flex-start;padding:10px 14px;margin-bottom:12px;border-left:3px solid #c77700">
          <div style="font-size:12px;color:var(--text-2);line-height:1.7;flex:1">
            <b>数据保存提醒</b><br>${inWeChat
              ? '微信内打开的网页数据<b>不会保留</b>（关闭微信即丢失）。请点右上角「···」→「在浏览器打开」，或安装到手机桌面使用，数据才能持久保存。'
              : '建议「添加到主屏幕」以 APP 方式使用——独立存储更稳定，不怕浏览器清理标签页数据。'}<br>已有数据可在「设置 → 导出备份」随时备份。
          </div>
          <button class="btn small ghost" style="flex-shrink:0" onclick="localStorage.setItem('gym_storage_hint_ok','1');Pages.render('today')">知道了</button>
        </div>`;
      }
    }

    // 统计
    const totalVol = workouts.reduce((a, w) => a + (w.entries || []).reduce((b, e) => b + e.sets.reduce((c, s) => c + (s.weight || 0) * (s.reps || 0), 0), 0), 0);
    // 连续训练周
    const weeks = new Set(workouts.map(w => { const d = new Date(w.date); const y = new Date(d); y.setDate(d.getDate() + 3 - (d.getDay() + 6) % 7); return fmtDateFull(y); }));
    let streak = 0;
    if (workouts.length) {
      const sorted = [...weeks].sort().reverse();
      let expect = null;
      for (const w of sorted) {
        if (expect === null || w === expect) { streak++; expect = this._prevWeek(expect || w); }
        else break;
      }
    }

    const exList = day.exercises.map(item => {
      const ex = getEx(item.exId); if (!ex) return '';
      const sug = Planner.suggestWeight(ex);
      return `<div class="ex-row" style="cursor:pointer" onclick="UI.showExercise('${ex.id}')">
        <img class="thumb" src="${ex.img}" loading="lazy" alt="">
        <div class="info">
          <div class="nm">${esc(ex.name_zh)}</div>
          <div class="sub"><span class="tag equip">${zh(ex.equipment)}</span><span class="tag cat">${zh(ex.target)}</span>${sug ? '<span>建议 ' + sug + 'kg' + (Planner.isDeload(ex) ? '（减载周）' : '') + '</span>' : ''}</div>
        </div>
        <div class="sets-info"><b>${item.sets}</b> 组 × <b>${item.reps}</b> 次<br><span style="font-size:10px;color:var(--text-3)">详情 ›</span></div>
      </div>`;
    }).join('');

    // 进行中的训练：按钮改为「继续训练」，直接回训练页不重建进度
    const active = Workout.session;
    const activeSameDay = active && active.dayIdx === dayIdx;
    const startBtn = active
      ? `<button class="btn" onclick="App.go('workout')">继续训练 →</button>`
      : `<button class="btn" onclick="Workout.start(${dayIdx})">开始训练 →</button>`;
    const activeBadge = active
      ? `<span style="display:inline-flex;align-items:center;gap:4px;font-size:11px;font-weight:600;color:#16a34a;background:#dcfce7;border-radius:999px;padding:2px 8px;margin-left:6px;vertical-align:1px"><span style="width:6px;height:6px;border-radius:50%;background:#16a34a;display:inline-block"></span>进行中</span>`
      : '';

    el.innerHTML = `
      ${storageHint}
      <div class="today-hero">
        <div class="label">今日训练 · 第 ${dayIdx + 1}/${plan.days.length} 天${activeBadge}</div>
        <div class="day-name">${esc(day.name)}</div>
        <div class="meta">${esc(plan.name)} · ${Planner.GOALS[plan.goal].label} · ${day.exercises.length} 个动作</div>
        ${startBtn}
        ${active && !activeSameDay ? '<div style="font-size:11px;color:var(--warn,#c77700);margin-top:6px">进行中的训练是「' + esc(active.dayName) + '」，点继续将回到该训练</div>' : ''}
      </div>
      <div class="stat-grid">
        <div class="stat-cell"><div class="num">${workouts.length}</div><div class="lbl">累计训练</div></div>
        <div class="stat-cell"><div class="num">${Math.round(totalVol / 1000)}k</div><div class="lbl">总容量 kg</div></div>
        <div class="stat-cell"><div class="num">${streak}</div><div class="lbl">连续训练周</div></div>
      </div>
      <div class="section-title">今日动作</div>
      ${exList}
    `;
  },

  _prevWeek(weekStr) {
    const d = new Date(weekStr); d.setDate(d.getDate() - 7);
    return fmtDateFull(d);
  },

  /* ── 方案页 ── */
  plan(el) {
    const plan = DB.getPlan();
    if (!plan) { el.innerHTML = '<div class="empty"><div class="big">无方案</div><p>还没有训练方案</p><button class="btn primary" onclick="App.go(\'settings\')">去创建</button></div>'; return; }

    const daysHtml = plan.days.map((day, i) => {
      const rows = day.exercises.map((item, j) => {
        const ex = getEx(item.exId); if (!ex) return '';
        const sug = Planner.suggestWeight(ex);
        const curW = item.weight != null ? item.weight : sug;
        return `<div class="plan-ex">
          <div class="plan-ex-top" onclick="UI.showExercise('${ex.id}')">
            <div class="nm">${esc(ex.name_zh)}${item.isMain === false ? ' <span class="tag">辅</span>' : ''} <span class="tag equip">${zh(ex.equipment)}</span> <span class="tag cat">${zh(ex.target)}</span></div>
            <span class="go">详情 ›</span>
          </div>
          <div class="plan-ex-body">
            <img class="thumb" src="${ex.img}" loading="lazy" alt="" onclick="UI.showExercise('${ex.id}')">
            <div class="plan-ex-body-info">
              <label class="w-edit">
                <input type="number" inputmode="decimal" step="2.5" min="0" value="${curW != null ? curW : ''}" placeholder="—" onchange="UI._setPlanWeight(${i},${j},this.value)">
                <span>kg</span>
              </label>
              <div class="sets-info"><b>${item.sets}</b>×<b>${item.reps}</b><br><span>${item.rest}s</span></div>
            </div>
            <button class="btn small ghost" onclick="UI.swapExercise(${i},${j})">换</button>
          </div>
        </div>`;
      }).join('');

      const warmupHtml = (day.warmup || []).length ? `
        <details style="margin-bottom:8px">
          <summary style="font-size:12px;font-weight:600;color:var(--ok);padding:6px 2px">热身 ${(day.warmup || []).length} 项（约 10 分钟）</summary>
          ${(day.warmup || []).map(w => `<div style="padding:5px 10px;border-left:2px solid var(--ok-soft);font-size:12px;color:var(--text-2)">
            <b style="color:var(--text)">${esc(w.label)}</b>${w.dur ? ' · ' + esc(w.dur) : ''}<br>${esc(w.detail)}</div>`).join('')}
        </details>` : '';

      const cooldownHtml = (day.cooldown || []).length ? `
        <details>
          <summary style="font-size:12px;font-weight:600;color:#3b6ea5;padding:6px 2px">放松拉伸 ${(day.cooldown || []).length} 个（每个 30s × 2 组）</summary>
          ${(day.cooldown || []).map(c => {
            const ex = getEx(c.exId); if (!ex) return '';
            return `<div style="display:flex;align-items:center;gap:10px;padding:5px 10px" onclick="UI.showExercise('${ex.id}')">
              <img src="${ex.img}" style="width:44px;height:34px;border-radius:6px;object-fit:cover" loading="lazy" alt="">
              <div style="font-size:13px">${esc(ex.name_zh)} <span style="color:var(--text-3);font-size:11px">${esc(c.dur)}</span></div>
            </div>`;
          }).join('')}
        </details>` : '';

      return `<div class="card">
        <h3>${esc(day.name)} <span class="tag">${day.exercises.length} 动作</span></h3>
        ${warmupHtml}
        ${rows}
        ${cooldownHtml}
      </div>`;
    }).join('');

    el.innerHTML = `
      <div class="card" style="display:flex;justify-content:space-between;align-items:center">
        <div>
          <div style="font-weight:700">${esc(plan.name)}</div>
          <div class="sub" style="font-size:12px;color:var(--text-2)">${Planner.GOALS[plan.goal].label} · ${plan.days.length} 天/轮 · 每动作可设定默认重量（kg），训练时自动带出</div>
        </div>
        <button class="btn small" onclick="UI.regenPlan()">重新生成</button>
      </div>
      ${daysHtml}
    `;
  },

  /* ── 动作库页 ── */
  libraryFilter: { category: '', equipment: '' },

  library(el) {
    const cats = [...new Set(EXERCISES.map(e => e.category))].sort();
    const equips = [...new Set(EXERCISES.map(e => e.equipment))].sort();
    const f = this.libraryFilter;

    const list = EXERCISES.filter(e =>
      (!f.category || e.category === f.category) &&
      (!f.equipment || e.equipment === f.equipment)
    );

    el.innerHTML = `
      <div class="filter-bar">
        <select onchange="Pages.libraryFilter.category=this.value;Pages.library(Pages._el())">
          <option value="">全部部位</option>
          ${cats.map(c => `<option value="${c}" ${f.category === c ? 'selected' : ''}>${zh(c)}</option>`).join('')}
        </select>
        <select onchange="Pages.libraryFilter.equipment=this.value;Pages.library(Pages._el())">
          <option value="">全部器械</option>
          ${equips.map(c => `<option value="${c}" ${f.equipment === c ? 'selected' : ''}>${zh(c)}</option>`).join('')}
        </select>
      </div>
      <div class="sub" style="font-size:12px;color:var(--text-2);margin:0 2px 8px">${list.length} 个动作</div>
      ${list.map(ex => `<div class="ex-row" onclick="UI.showExercise('${ex.id}')">
        <img class="thumb" src="${ex.img}" loading="lazy" alt="">
        <div class="info">
          <div class="nm">${esc(ex.name_zh)}</div>
          <div class="sub">${zh(ex.equipment)} · ${zh(ex.target)}</div>
        </div>
        <span class="tag ${ex.kind === 'stretch' ? '' : 'cat'}" ${ex.kind === 'stretch' ? 'style="background:#e8f0fb;color:#3b6ea5"' : ''}>${ex.kind === 'stretch' ? '拉伸' : zh(ex.category)}</span>
      </div>`).join('')}
    `;
  },
  _el() { return document.getElementById('page-library'); },

  /* ── 数据页 ── */
  stats(el) {
    const workouts = DB.getWorkouts();
    const body = DB.getBody();

    // 无训练记录：只显示空状态，不渲染空图表
    if (workouts.length === 0) {
      el.innerHTML = '<div class="empty"><div class="big">📊</div><p style="font-weight:600;color:var(--text-2)">还没有训练记录</p><p style="font-size:13px;margin-top:4px">完成第一次训练后，容量趋势和动作重量曲线会出现在这里</p></div>';
      return;
    }

    // 周容量（近 12 周）
    const weekMap = new Map();
    for (let i = 11; i >= 0; i--) {
      const d = new Date(); d.setDate(d.getDate() - 7 * i);
      const y = new Date(d); y.setDate(d.getDate() + 3 - (d.getDay() + 6) % 7);
      weekMap.set(fmtDateFull(y), 0);
    }
    workouts.forEach(w => {
      const d = new Date(w.date);
      const y = new Date(d); y.setDate(d.getDate() + 3 - (d.getDay() + 6) % 7);
      const key = fmtDateFull(y);
      if (weekMap.has(key)) {
        const vol = (w.entries || []).reduce((b, e) => b + e.sets.reduce((c, s) => c + (s.weight || 0) * (s.reps || 0), 0), 0);
        weekMap.set(key, weekMap.get(key) + vol);
      }
    });

    // 有记录的动作
    const idSets = workouts.map(w => (w.entries || []).map(e => e.exId));
    const seen = {};
    const trainedIds = [];
    idSets.forEach(ids => ids.forEach(id => { if (!seen[id]) { seen[id] = true; trainedIds.push(id); } }));
    const trainedIdsFiltered = trainedIds.filter(id => getEx(id));

    el.innerHTML = `
      <div class="chart-box">
        <h3>每周训练容量</h3>
        <div class="hint-s">近 12 周 · kg</div>
        ${this._barChart([...weekMap.entries()])}
      </div>
      <div class="chart-box">
        <h3>动作重量曲线</h3>
        <div class="hint-s">渐进超载追踪</div>
        ${trainedIdsFiltered.length ? `
        <select onchange="Pages._weightChart(this.value)">
          ${trainedIdsFiltered.map(id => `<option value="${id}">${esc(getEx(id).name_zh)}</option>`).join('')}
        </select>
        <div id="weight-chart"></div>` : '<div class="hint-s">暂无记录</div>'}
      </div>
      <div class="chart-box">
        <h3>身体指标</h3>
        <div style="display:flex;gap:8px;margin-bottom:10px;flex-wrap:wrap">
          <input id="body-w" type="number" step="0.1" placeholder="体重 kg" style="flex:1;min-width:90px;padding:8px;border:1px solid var(--border);border-radius:8px">
          <input id="body-chest" type="number" step="0.5" placeholder="胸围 cm" style="flex:1;min-width:90px;padding:8px;border:1px solid var(--border);border-radius:8px">
          <input id="body-waist" type="number" step="0.5" placeholder="腰围 cm" style="flex:1;min-width:90px;padding:8px;border:1px solid var(--border);border-radius:8px">
          <button class="btn small primary" onclick="Pages._saveBody()">记录</button>
        </div>
        <div id="body-chart">${this._bodyChart(body)}</div>
      </div>
      ${workouts.slice(-10).reverse().map(w => `<div class="card" style="padding:10px 14px">
        <b style="font-size:13px">${w.dayName || '训练'}</b>
        <span style="font-size:12px;color:var(--text-2)"> ${fmtDate(w.date)} · ${(w.entries || []).reduce((b, e) => b + e.sets.reduce((c, s) => c + (s.weight || 0) * (s.reps || 0), 0), 0)} kg · ${(w.entries || []).reduce((b, e) => b + e.sets.filter(s => s.reps > 0).length, 0)} 组</span>
      </div>`).join('')}
    `;
    if (trainedIdsFiltered.length) this._weightChart(trainedIdsFiltered[0]);
  },

  _barChart(data) {
    const max = Math.max(...data.map(d => d[1]), 1);
    const W = 600, H = 150, bw = W / data.length;
    const bars = data.map(([label, v], i) => {
      const h = v / max * (H - 30);
      const x = i * bw + 4, y = H - 20 - h;
      return `<rect x="${x}" y="${y}" width="${bw - 8}" height="${Math.max(h, v > 0 ? 2 : 0)}" rx="3" fill="${v > 0 ? '#ff4f00' : '#e4e4e7'}"/>
        ${v > 0 ? `<text x="${x + (bw - 8) / 2}" y="${y - 4}" font-size="10" fill="#71717a" text-anchor="middle">${Math.round(v / 100) / 10}k</text>` : ''}`;
    }).join('');
    const labels = data.map(([label], i) => i % 3 === 0 ? `<text x="${i * bw + bw / 2}" y="${H - 5}" font-size="9" fill="#a1a1aa" text-anchor="middle">${label.slice(5).replace('-', '/')}</text>` : '').join('');
    return `<svg viewBox="0 0 ${W} ${H}">${bars}${labels}</svg>`;
  },

  _weightChart(exId) {
    const hist = DB.historyOf(exId);
    const el = document.getElementById('weight-chart');
    if (!el) return;
    if (!hist.length) { el.innerHTML = '<div class="hint-s">暂无记录</div>'; return; }
    const pts = hist.map(h => ({ d: h.date, w: Math.max(...h.sets.map(s => s.weight), 0) })).filter(p => p.w > 0);
    if (!pts.length) { el.innerHTML = '<div class="hint-s">暂无负重记录</div>'; return; }
    const W = 600, H = 160, pad = 30;
    const minW = Math.min(...pts.map(p => p.w)), maxW = Math.max(...pts.map(p => p.w));
    const rng = Math.max(maxW - minW, 2.5);
    const x = i => pad + i * (W - pad * 2) / Math.max(pts.length - 1, 1);
    const y = w => H - pad - (w - minW) / rng * (H - pad * 2);
    const path = pts.map((p, i) => `${i ? 'L' : 'M'}${x(i)},${y(p.w)}`).join(' ');
    const dots = pts.map((p, i) => `<circle cx="${x(i)}" cy="${y(p.w)}" r="3.5" fill="#ff4f00"/>
      <text x="${x(i)}" y="${y(p.w) - 8}" font-size="10" fill="#71717a" text-anchor="middle">${p.w}</text>`).join('');
    const xlabels = pts.map((p, i) => (pts.length <= 8 || i % Math.ceil(pts.length / 6) === 0) ? `<text x="${x(i)}" y="${H - 8}" font-size="9" fill="#a1a1aa" text-anchor="middle">${fmtDate(p.d)}</text>` : '').join('');
    el.innerHTML = `<svg viewBox="0 0 ${W} ${H}"><path d="${path}" fill="none" stroke="#ff4f00" stroke-width="2" stroke-linejoin="round"/>${dots}${xlabels}</svg>`;
  },

  _saveBody() {
    const w = parseFloat(document.getElementById('body-w').value);
    const chest = parseFloat(document.getElementById('body-chest').value);
    const waist = parseFloat(document.getElementById('body-waist').value);
    if (!w && !chest && !waist) { toast('至少填写一项'); return; }
    DB.addBody({ date: new Date().toISOString(), weight: w || null, chest: chest || null, waist: waist || null });
    toast('已记录');
    this.stats(document.getElementById('page-stats'));
  },

  _bodyChart(body) {
    if (!body.length) return '<div class="hint-s">暂无记录</div>';
    const W = 600, H = 140, pad = 30;
    const valid = body.filter(b => b.weight);
    if (!valid.length) return '<div class="hint-s">暂无体重记录</div>';
    const ws = valid.map(b => b.weight);
    const minW = Math.min(...ws), maxW = Math.max(...ws);
    const rng = Math.max(maxW - minW, 1);
    const x = i => pad + i * (W - pad * 2) / Math.max(valid.length - 1, 1);
    const y = w => H - pad - (w - minW) / rng * (H - pad * 2);
    const path = valid.map((b, i) => `${i ? 'L' : 'M'}${x(i)},${y(b.weight)}`).join(' ');
    const dots = valid.map((b, i) => `<circle cx="${x(i)}" cy="${y(b.weight)}" r="3" fill="#0f766e"/>`).join('');
    const labels = valid.map((b, i) => (valid.length <= 8 || i % Math.ceil(valid.length / 5) === 0) ? `<text x="${x(i)}" y="${H - 8}" font-size="9" fill="#a1a1aa" text-anchor="middle">${fmtDate(b.date)}</text>` : '').join('');
    const last = valid[valid.length - 1];
    return `<div class="hint-s" style="margin-bottom:2px">最新体重 <b style="color:var(--ok)">${last.weight}kg</b></div><svg viewBox="0 0 ${W} ${H}"><path d="${path}" fill="none" stroke="#0f766e" stroke-width="2"/>${dots}${labels}</svg>`;
  },
};

/* ── 弹窗 UI ── */
const UI = {
  showExercise(id) {
    const ex = getEx(id); if (!ex) return;
    const hist = DB.historyOf(id);
    const lastW = DB.lastWorkingWeight(id);
    const steps = (ex.instructions_zh || []).map((s, i) => `<li data-n="${i + 1}">${esc(s)}</li>`).join('');
    const histHtml = hist.length ? `<div class="instr-label">训练历史</div>
      ${hist.slice(-3).reverse().map(h => `<div style="font-size:12px;color:var(--text-2);padding:3px 0">
        ${fmtDate(h.date)} · ${h.sets.map(s => s.reps > 0 ? `${s.weight || 0}kg×${s.reps}` : '').filter(Boolean).join('，')}</div>`).join('')}` : '';
    openSheet(`
      <h2>${esc(ex.name_zh)}<div style="font-size:12px;font-weight:400;color:var(--text-2)">${esc(ex.name)}</div></h2>
      <div class="gif-wrap"><img src="${ex.gif}" alt="${esc(ex.name_zh)}" onerror="if(this.src!=='${ex.img}')this.src='${ex.img}'"></div>
      <div class="meta-chips">
        <span class="meta-chip"><b>${zh(ex.category)}</b></span>
        <span class="meta-chip"><b>${zh(ex.equipment)}</b></span>
        <span class="meta-chip">目标 <b>${zh(ex.target)}</b></span>
        ${ex.muscle_group && ex.muscle_group !== ex.target ? `<span class="meta-chip">肌群 <b>${zh(ex.muscle_group)}</b></span>` : ''}
        ${lastW ? `<span class="meta-chip" style="background:#e6f4f2;color:#0f766e">上次 <b>${lastW}kg</b></span>` : ''}
      </div>
      ${(ex.instructions_zh || []).length ? `<div class="instr-label">动作要领</div><ol class="instr-list">${steps}</ol>` : ''}
      ${histHtml}
    `);
  },

  swapExercise(dayIdx, itemIdx) {
    const plan = DB.getPlan();
    const item = plan.days[dayIdx].exercises[itemIdx];
    const alts = Planner.alternatives(item.exId);
    openSheet(`
      <h2>替换动作</h2>
      <div class="hint-s" style="font-size:12px;color:var(--text-2);margin-bottom:10px">当前：${esc(getEx(item.exId).name_zh)}</div>
      <input id="swap-search" type="text" placeholder="搜索全部动作…" oninput="UI._swapSearch(${dayIdx},${itemIdx},this.value)" style="width:100%;padding:10px 12px;border:1.5px solid var(--border);border-radius:10px;font-size:14px;outline:none;margin-bottom:4px">
      <div class="hint-s" style="font-size:11px;color:var(--text-3);margin:4px 2px 8px">下方为同模式推荐（${alts.length} 个）；搜索可从全部动作中选择</div>
      <div id="swap-list">${alts.map(a => `<div class="ex-row" onclick="UI._doSwap(${dayIdx},${itemIdx},'${a.id}')">
        <img class="thumb" src="${a.img}" loading="lazy" alt="">
        <div class="info"><div class="nm">${esc(a.name_zh)}</div><div class="sub">${zh(a.equipment)} · ${zh(a.target)}</div></div>
        <span class="tag main">推荐</span>
      </div>`).join('')}</div>
    `);
  },
  _swapSearch(dayIdx, itemIdx, q) {
    const list = document.getElementById('swap-list');
    if (!list) return;
    q = (q || '').trim().toLowerCase();
    if (!q) {
      // 无搜索词：恢复推荐列表
      this.swapExercise(dayIdx, itemIdx);
      return;
    }
    const cur = DB.getPlan().days[dayIdx].exercises[itemIdx].exId;
    const hits = EXERCISES.filter(e => {
      if (e.kind === 'stretch' || e.id === cur) return false;
      return (e.name_zh + ' ' + e.name).toLowerCase().includes(q);
    }).slice(0, 30);
    list.innerHTML = hits.length ? hits.map(a => `<div class="ex-row" onclick="UI._doSwap(${dayIdx},${itemIdx},'${a.id}')">
      <img class="thumb" src="${a.img}" loading="lazy" alt="">
      <div class="info"><div class="nm">${esc(a.name_zh)}</div><div class="sub">${zh(a.equipment)} · ${zh(a.target)}</div></div>
    </div>`).join('') : '<div class="empty" style="padding:20px"><p>没有匹配的动作</p></div>';
  },
  _setPlanWeight(dayIdx, itemIdx, val) {
    const plan = DB.getPlan();
    const item = plan.days[dayIdx].exercises[itemIdx];
    const v = parseFloat(val);
    item.weight = isNaN(v) ? null : v;
    DB.setPlan(plan);
  },
  _doSwap(dayIdx, itemIdx, newId) {
    const plan = DB.getPlan();
    plan.days[dayIdx].exercises[itemIdx].exId = newId;
    DB.setPlan(plan);
    closeSheet();
    toast('已替换为 ' + getEx(newId).name_zh);
    Pages.render('plan');
  },

  regenPlan() {
    const plan = DB.getPlan();
    const newPlan = Planner.generate(plan.split, plan.goal);
    DB.setPlan(newPlan);
    DB.setPlanState({ dayCursor: 0 });
    toast('已重新生成方案');
    Pages.render('plan');
  },
};

let _sheetOpen = false;
function openSheet(html) {
  let overlay = document.getElementById('sheet-overlay');
  if (!overlay) {
    overlay = document.createElement('div');
    overlay.id = 'sheet-overlay';
    overlay.className = 'overlay';
    overlay.innerHTML = '<div class="sheet" style="position:relative"><button class="close-x" onclick="closeSheet()">✕</button><div id="sheet-content"></div></div>';
    overlay.addEventListener('click', e => { if (e.target === overlay) closeSheet(); });
    document.body.appendChild(overlay);
  }
  document.getElementById('sheet-content').innerHTML = html;
  overlay.classList.add('open');
  document.body.classList.add('modal-open');
  // 侧滑返回拦截：pushState 占位，Android 侧滑返回手势/返回键先关弹窗而不是退出 APP
  _sheetOpen = true;
  history.pushState({ sheet: true }, '', location.href);
}
function closeSheet() {
  const o = document.getElementById('sheet-overlay');
  if (o) o.classList.remove('open');
  document.body.classList.remove('modal-open');
  if (_sheetOpen) {
    _sheetOpen = false;
    history.back(); // 平衡 pushState 占位
  }
}
// 全局返回手势/返回键：弹窗开着时只关弹窗（popstate 已消费历史，不再 back）
window.addEventListener('popstate', () => {
  if (_sheetOpen) {
    _sheetOpen = false;
    const o = document.getElementById('sheet-overlay');
    if (o) o.classList.remove('open');
    document.body.classList.remove('modal-open');
  }
});
